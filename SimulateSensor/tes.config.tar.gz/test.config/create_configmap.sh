stt=1
## sleep in bash for loop ##
# create sensor item
for i in {1..6}
do
  kubectl create configmap sensor-items --from-file=sensor.items/items.$i.cfg --namespace kube-system
  #sleep 1h
done
# create sensor config
 kubectl create configmap sensor-config --from-file=sensor.config/config.cfg --namespace kube-system

# create onem2m config
 kubectl create configmap onem2m-config --from-file=onem2m.config/config.cfg --namespace kube-system

# create openhab config
 kubectl create configmap openhab-cfg --from-file=openhab.config/config.cfg --namespace kube-system

# create onem2m item
for i in {1..3}
do
  kubectl create configmap onem2m-items-$i --from-file=onem2m.items/items.$i.cfg --namespace kube-system
done

# create openhab item
for i in {1..3}
do
  kubectl create configmap openhab-items-$i --from-file=openhab.items/demo.$i.items --namespace kube-system
done
