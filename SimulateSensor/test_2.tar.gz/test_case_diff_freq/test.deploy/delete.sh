kubectl delete -f onem2m.deploy/
kubectl delete -f openhab.deploy/
kubectl delete -f sensor.deploy/
